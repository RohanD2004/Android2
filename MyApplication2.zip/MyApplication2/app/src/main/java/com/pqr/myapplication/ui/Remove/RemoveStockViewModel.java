package com.pqr.myapplication.ui.Remove;

import androidx.lifecycle.ViewModel;

public class RemoveStockViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}