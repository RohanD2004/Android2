package com.pqr.myapplication.ui.Add;

import androidx.lifecycle.ViewModel;

public class AddStockViewModel extends ViewModel {



    // TODO: Implement the ViewModel
}