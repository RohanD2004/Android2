package com.pqr.myapplication.ui.Bill;

import androidx.lifecycle.ViewModel;

public class GenerateBillViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}